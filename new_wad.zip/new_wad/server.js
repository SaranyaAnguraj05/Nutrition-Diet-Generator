const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const validator = require('validator');
const bodyParser = require('body-parser');
const path = require('path');
const cookieParser = require('cookie-parser'); // Import cookie parser

const app = express();
const PORT = 3000;

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/diet', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.log('MongoDB connection error:', err));

// Define Schemas and Models

// Login schema
const loginSchema = new mongoose.Schema({
    email: { type: String, required: true, unique: true },
    phone: { type: String, required: true },
    password: { type: String, required: true }
});
const Login = mongoose.model('Login', loginSchema);

// Preferences schema
const userSchema = new mongoose.Schema({
    email: { type: String, required: true, unique: true },
    name: String,
    dob: Date,
    gender: String,
    bloodGroup: String,
    height: Number,
    weight: Number,
    bmi: Number,
    bmiStatus: String // Add bmiStatus field to store status (Underweight, Balanced, Overweight)
});
const User = mongoose.model('users', userSchema);

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());
app.use(cookieParser()); // Use cookie parser middleware
app.use(express.static(path.join(__dirname, 'public')));
app.set('views', path.join(__dirname, 'views'));

// Routes

// Dynamic health messages for the landing page
const healthMessages = [
    "Drink plenty of water daily to stay hydrated.",
    "Regular exercise boosts your immune system.",
    "Eat a balanced diet rich in fruits and vegetables.",
    "Take short breaks from sitting every hour.",
    "Get 7-8 hours of quality sleep every night."
];

// Landing page route
app.get('/index', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Signup route
app.get('/signup', (req, res) => {
    res.sendFile(path.join(__dirname, 'signup.html'));
});

app.post('/signup', async (req, res) => {
    const { email, phone, password, confirmPassword } = req.body;

    // Validations
    if (!validator.isEmail(email)) {
        return res.send('Invalid email');
    }

    if (!/^[0-9]{10}$/.test(phone)) {
        return res.send('Phone number should be 10 digits');
    }

    if (password !== confirmPassword) {
        return res.send('Passwords do not match');
    }

    if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}/.test(password)) {
        return res.send('Password must contain upper, lower, digit, special character, and be at least 8 characters');
    }

    // Hash password before storing it
    const hashedPassword = await bcrypt.hash(password, 10);

    // Save user to the database
    const user = new Login({ email, phone, password: hashedPassword });
    await user.save();

    // Store email in the cookie for future requests
    res.cookie('userEmail', email, { httpOnly: true, secure: false, maxAge: 3600000 }); // 1 hour expiry

    res.send('Signup successful!');// Redirect to profile page after signup
});

// Login route
app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'login.html'));
});

app.post('/login', async (req, res) => {
    const { email, password } = req.body;

    const user = await Login.findOne({ email });
    if (!user) {
        return res.send('User not found');
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
        return res.send('Invalid credentials');
    }

    // Store email in the cookie for future requests
    res.cookie('userEmail', user.email, { httpOnly: true, secure: false, maxAge: 3600000 }); // 1 hour expiry

    // Redirect to user profile page
    res.redirect('/preferences');
});

// Forgot Password route
app.get('/forgot-password', (req, res) => {
    res.sendFile(path.join(__dirname, 'forgot-password.html'));
});

app.post('/reset-password', async (req, res) => {
    const { email } = req.body;

    try {
        const user = await Login.findOne({ email });
        if (!user) {
            return res.status(404).send('Email not found');
        }

        const newPassword = Math.random().toString(36).slice(-8);
        const hashedPassword = await bcrypt.hash(newPassword, 10);

        user.password = hashedPassword;
        await user.save();

        res.status(200).send(`Your new password is: ${newPassword}`);
    } catch (err) {
        res.status(500).send('Error resetting password: ' + err.message);
    }
});

// Preferences route
app.get('/preferences', (req, res) => {
    res.sendFile(path.join(__dirname, 'preferences.html'));
});

app.post('/preferences', async (req, res) => {
    try {
        const { name, dob, gender, bloodGroup, height, weight } = req.body;

        // Calculate BMI
        const bmi = (weight / ((height / 100) * (height / 100))).toFixed(2);

        // Determine BMI status
        let bmiStatus = '';
        if (bmi < 18.5) {
            bmiStatus = 'Underweight';
        } else if (bmi >= 18.5 && bmi < 24.9) {
            bmiStatus = 'Balanced';
        } else {
            bmiStatus = 'Overweight';
        }

        // Get the user's email from the cookie
        const email = req.cookies.userEmail;
        if (!email) {
            return res.send('User not logged in');
        }

        // Save user data in the database
        const newUser = new User({ email, name, dob, gender, bloodGroup, height, weight, bmi, bmiStatus });
        await newUser.save();

        res.send('Your preferences have been saved successfully! <a href="/profile">Go to Profile</a>');
    } catch (err) {
        res.status(500).send('Error saving preferences: ' + err.message);
    }
});

// Profile route
app.get('/profile', async (req, res) => {
    const email = req.cookies.userEmail;

    if (!email) {
        return res.send('User not logged in');
    }

    // Fetch user preferences from the User collection based on the email
    const user = await User.findOne({ email });

    if (!user) {
        return res.send('User preferences not found');
    }

    res.send(`
        <h1>Profile</h1>
        <p>Name: ${user.name}</p>
        <p>Date of Birth: ${user.dob}</p>
        <p>Gender: ${user.gender}</p>
        <p>Blood Group: ${user.bloodGroup}</p>
        <p>Height: ${user.height} cm</p>
        <p>Weight: ${user.weight} kg</p>
        <p>BMI: ${user.bmi}</p>
        <p>BMI Status: ${user.bmiStatus}</p>
    `);
});

// Diet chart route
app.get('/diet-chart', (req, res) => {
    res.send('<h1>Diet Chart Coming Soon!</h1>');
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
